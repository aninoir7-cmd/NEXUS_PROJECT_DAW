NEXUS PROJECT DAW — PWA

Versión corregida para GitHub Pages en /NEXUS_PROJECT_DAW/.

Correcciones:
- Rana usa BASE_URL para funcionar dentro de la ruta del repositorio.
- Manifest usa rutas relativas.
- Service Worker usa la ruta base de GitHub Pages.
- Mantiene la interfaz Matrix y la gestión de temas/archivos.
